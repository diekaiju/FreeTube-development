export {
  settings as DBSettingHandlers,
  history as DBHistoryHandlers,
  profiles as DBProfileHandlers,
  playlists as DBPlaylistHandlers,
  searchHistory as DBSearchHistoryHandlers,
  subscriptionCache as DBSubscriptionCacheHandlers,
} from 'DB_HANDLERS_ELECTRON_RENDERER_OR_WEB'
