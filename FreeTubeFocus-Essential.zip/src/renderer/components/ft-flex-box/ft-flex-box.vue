<template>
  <div class="ft-flex-box">
    <slot class="flex-container" />
  </div>
</template>

<script src="./ft-flex-box.js" />
<style scoped src="./ft-flex-box.css" />
